"""
Based on https://github.com/pypa/pip/commit/57be6a77c57ab5d512371b5c48d508a7620c3217
"""
